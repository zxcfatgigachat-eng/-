import ProductList from "@/components/ProductList";

interface Product {
  id: number;
  name: string;
  price: number;
  description: string;
  category: string;
}

const products: Product[] = [
  {
    id: 1,
    name: "Смартфон Xiaomi",
    price: 15990,
    description: "Хороший телефон с большой батареей",
    category: "Электроника",
  },
  {
    id: 2,
    name: "Наушники Sony",
    price: 4990,
    description: "Беспроводные наушники с шумоподавлением",
    category: "Электроника",
  },
  {
    id: 3,
    name: "Футболка хлопковая",
    price: 890,
    description: "Мягкая футболка из 100% хлопка",
    category: "Одежда",
  },
  {
    id: 4,
    name: "Кроссовки Nike",
    price: 7990,
    description: "Удобные кроссовки для бега",
    category: "Одежда",
  },
  {
    id: 5,
    name: "Кофеварка Delonghi",
    price: 12990,
    description: "Автоматическая кофеварка для дома",
    category: "Бытовая техника",
  },
  {
    id: 6,
    name: "Книга Гарри Поттер",
    price: 650,
    description: "Первая книга серии о Гарри Поттере",
    category: "Книги",
  },
  {
    id: 7,
    name: "Рюкзак городской",
    price: 2490,
    description: "Вместительный рюкзак для учебы и работы",
    category: "Аксессуары",
  },
  {
    id: 8,
    name: "Часы Casio",
    price: 3490,
    description: "Надежные часы с подсветкой",
    category: "Аксессуары",
  },
  {
    id: 9,
    name: "Планшет Samsung",
    price: 18990,
    description: "Планшет для работы и развлечений",
    category: "Электроника",
  },
  {
    id: 10,
    name: "Джинсы Levi's",
    price: 4590,
    description: "Классические джинсы синего цвета",
    category: "Одежда",
  },
  {
    id: 11,
    name: "Блендер Philips",
    price: 3990,
    description: "Мощный блендер для смузи",
    category: "Бытовая техника",
  },
  {
    id: 12,
    name: "Мышь Logitech",
    price: 1290,
    description: "Беспроводная мышь для компьютера",
    category: "Электроника",
  },
];

export default function Home() {
  return (
    <main className="min-h-screen p-8">
      <h1 className="text-3xl font-bold text-center mb-8">
        Каталог товаров
      </h1>
      <ProductList products={products} />
    </main>
  );
}

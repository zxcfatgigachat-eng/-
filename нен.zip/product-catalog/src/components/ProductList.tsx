"use client";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

interface Product {
  id: number;
  name: string;
  price: number;
  description: string;
  category: string;
}

interface ProductListProps {
  products: Product[];
}

export default function ProductList({ products }: ProductListProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
      {products.map((product) => (
        <Card key={product.id}>
          <CardHeader>
            <div className="mb-2">
              <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                {product.category}
              </span>
            </div>
            <CardTitle className="text-xl">{product.name}</CardTitle>
            <CardDescription>{product.description}</CardDescription>
          </CardHeader>
          <CardContent>
            <span className="text-lg font-bold text-green-600">
              {product.price.toLocaleString("ru-RU")} ₽
            </span>
          </CardContent>
          <CardFooter>
            <button className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 text-sm w-full">
              В корзину
            </button>
          </CardFooter>
        </Card>
      ))}
    </div>
  );
}
